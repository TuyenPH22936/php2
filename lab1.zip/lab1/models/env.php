<?php
//điều chỉnh kết nối db ở đây
const DBNAME = "wd18205";
const DBUSER = "root";
const DBPASS = "";
const DBCHARSET = "utf8";
const DBHOST = "127.0.0.1";

